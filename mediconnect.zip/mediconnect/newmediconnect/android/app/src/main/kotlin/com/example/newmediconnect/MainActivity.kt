package com.example.newmediconnect

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
