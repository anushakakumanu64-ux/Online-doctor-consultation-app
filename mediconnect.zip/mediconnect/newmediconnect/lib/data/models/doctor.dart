class Doctor {
  final String id;
  final String name;
  final String speciality;
  final double rating;
  final String imageUrl;

  final int experience;
  final String clinic;
  final double fees;
  final String contact;
  final String bio;
  final List<String> reviews;

  Doctor({
    required this.id,
    required this.name,
    required this.speciality,
    required this.rating,
    required this.imageUrl,
    required this.experience,
    required this.clinic,
    required this.fees,
    required this.contact,
    required this.bio,
    required this.reviews,
  });

  factory Doctor.fromJson(Map<String, dynamic> json) => Doctor(
    id: json['id'] ?? '',
    name: json['name'] ?? '',
    speciality: json['speciality'] ?? '',
    rating: (json['rating'] ?? 0).toDouble(),
    imageUrl: json['imageUrl'] ?? '',
    experience: json['experience'] ?? 0,
    clinic: json['clinic'] ?? '',
    fees: (json['fees'] ?? 0).toDouble(),
    contact: json['contact'] ?? '',
    bio: json['bio'] ?? '',
    reviews: json['reviews'] ?? '',
  );
}
