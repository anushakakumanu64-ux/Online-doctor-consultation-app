class Prescription {
  final String id;
  final String appointmentId;
  final String notes;
  final List<String> medicines;

  Prescription({
    required this.id,
    required this.appointmentId,
    required this.notes,
    required this.medicines,
  });
}
