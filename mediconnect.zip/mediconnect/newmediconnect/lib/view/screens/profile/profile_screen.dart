import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../view_model/theme_view_model.dart';
import '../../widgets/custom_app_bar.dart';
import '../auth/login_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String storedEmail = '';
  String storedName = '';
  bool notificationsEnabled = true;
  bool locationEnabled = false;
  final prefs = SharedPreferences.getInstance();

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      storedEmail = prefs.getString('email') ?? '';
      storedName = prefs.getString('name') ?? '';
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeViewModel = Provider.of<ThemeViewModel>(context);
    final theme = Theme.of(context);
    final textColor = theme.textTheme.bodyLarge?.color ?? Colors.black;

    return Scaffold(
      appBar: CustomAppBar(title: 'Profile & Settings'),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Profile Header
            Row(
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundColor: theme.colorScheme.primary.withOpacity(0.1),
                  backgroundImage: const NetworkImage(
                    'https://i.pravatar.cc/150?img=3',
                  ),
                  child: const Icon(Icons.person, size: 40, color: Colors.grey),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      storedName,
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      storedEmail,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: textColor.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Profile Options Card
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  _buildSettingsTile(
                    icon: Icons.edit,
                    title: 'Edit Profile',
                    onTap: () {},
                    textColor: textColor,
                  ),
                  _buildSettingsTile(
                    icon: Icons.lock,
                    title: 'Change Password',
                    onTap: () {},
                    textColor: textColor,
                  ),
                  _buildSettingsTile(
                    icon: Icons.help_outline,
                    title: 'Help & Support',
                    onTap: () {},
                    textColor: textColor,
                  ),
                  _buildSettingsTile(
                    icon: Icons.logout,
                    title: 'Logout',
                    onTap: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const AuthScreen(),
                        ),
                      );
                    },
                    textColor: Colors.red,
                    iconColor: Colors.red,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Preferences Card with switches
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                children: [
                  SwitchListTile(
                    title: Text(
                      'Dark Mode',
                      style: TextStyle(color: textColor),
                    ),
                    secondary: Icon(Icons.dark_mode, color: textColor),
                    value: themeViewModel.isDarkMode,
                    onChanged: (val) => themeViewModel.toggleTheme(val),
                  ),
                  SwitchListTile(
                    title: Text(
                      'Enable Notifications',
                      style: TextStyle(color: textColor),
                    ),
                    secondary: Icon(Icons.notifications, color: textColor),
                    value: notificationsEnabled,
                    onChanged: (val) {
                      setState(() => notificationsEnabled = val);
                    },
                  ),
                  SwitchListTile(
                    title: Text(
                      'Location Access',
                      style: TextStyle(color: textColor),
                    ),
                    secondary: Icon(Icons.location_on, color: textColor),
                    value: locationEnabled,
                    onChanged: (val) {
                      setState(() => locationEnabled = val);
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSettingsTile({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    Color? textColor,
    Color? iconColor,
  }) {
    return ListTile(
      leading: Icon(icon, color: iconColor ?? textColor ?? Colors.black),
      title: Text(title, style: TextStyle(color: textColor ?? Colors.black)),
      trailing: Icon(Icons.chevron_right, color: textColor ?? Colors.black),
      onTap: onTap,
    );
  }
}
