import 'package:flutter/material.dart';
import '../../widgets/custom_app_bar.dart';

class PrescriptionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Prescription'),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Card(
          child: Padding(
            padding: EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Prescription for Appointment #1'),
                SizedBox(height: 8),
                Text('1. Paracetamol 500mg - 1 tablet twice daily'),
                SizedBox(height: 8),
                Text('Notes: Take after food'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
