import 'dart:async';
import 'package:flutter/material.dart';
import '../../widgets/bottom_nav.dart';
import '../../widgets/doctor_card.dart';
import '../../../core/utils/constants.dart';
import '../../../data/services/mock_api_service.dart';
import '../../../data/models/doctor.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;
  List<Doctor> _doctors = [];
  bool _loading = true;
  final TextEditingController _searchController = TextEditingController();
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _loadDoctors();

    _searchController.addListener(() {
      _onSearchChanged(_searchController.text);
    });
  }

  void _loadDoctors() async {
    final docs = await MockApiService.fetchDoctors();
    setState(() {
      _doctors = docs;
      _loading = false;
    });
  }

  void _onSearchChanged(String query) {
    if (_debounce?.isActive ?? false) _debounce!.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () {
      _sortDoctors(query);
    });
  }

  void _sortDoctors(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return;

    setState(() {
      _doctors.sort((a, b) {
        final aMatches =
            (a.name.toLowerCase().contains(q) ||
            a.speciality.toLowerCase().contains(q));
        final bMatches =
            (b.name.toLowerCase().contains(q) ||
            b.speciality.toLowerCase().contains(q));

        if (aMatches && !bMatches) return -1; // a goes before b
        if (!aMatches && bMatches) return 1; // b goes before a
        return 0; // no change
      });
    });
  }

  void _onNavTap(int idx) {
    setState(() => _selectedIndex = idx);
    switch (idx) {
      case 1:
        Navigator.pushNamed(context, Routes.appointment);
        break;
      case 2:
        Navigator.pushNamed(context, Routes.records);
        break;
      case 3:
        Navigator.pushNamed(context, Routes.profile);
        break;
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(50),
            child: Image.network(
              "https://media.istockphoto.com/id/471629610/vector/caduceus-medical-symbol.jpg?s=612x612&w=0&k=20&c=jLnfdQQphRwsmm6wo0O80sEo-5PhbEY4PHmQgBiRkq0=",
              fit: BoxFit.fill,
            ),
          ),
        ),
        title: Text(
          "MediConnect",
          style: theme.textTheme.bodyMedium?.copyWith(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        backgroundColor: theme.appBarTheme.backgroundColor,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Find a Specialist'),
            const SizedBox(height: 8),
            TextField(
              controller: _searchController,
              style: TextStyle(color: theme.textTheme.bodyMedium?.color),
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.search, color: theme.iconTheme.color),
                hintText: 'Search doctors, specialities',
                hintStyle: TextStyle(color: theme.hintColor),
                filled: true,
                fillColor: theme.cardColor,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      itemCount: _doctors.length,
                      itemBuilder: (context, index) {
                        final d = _doctors[index];
                        return DoctorCard(
                          name: d.name,
                          speciality: d.speciality,
                          rating: d.rating,
                          imageUrl: d.imageUrl,
                          onTap: () => Navigator.pushNamed(
                            context,
                            Routes.doctorList,
                            arguments: d,
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: AppBottomNav(
        selectedIndex: _selectedIndex,
        onTap: _onNavTap,
      ),
    );
  }
}
