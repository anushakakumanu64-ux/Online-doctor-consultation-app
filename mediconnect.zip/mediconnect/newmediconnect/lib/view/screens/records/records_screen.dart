import 'package:flutter/material.dart';
import '../../widgets/custom_app_bar.dart';

class RecordsScreen extends StatelessWidget {
  final List<Map<String, String>> records = [
    {
      'date': '2025-01-10',
      'title': 'Blood Test',
      'type': 'PDF',
      'description': 'Routine blood analysis results.',
    },
    {
      'date': '2025-02-20',
      'title': 'X-Ray',
      'type': 'Image',
      'description': 'Chest X-Ray scan.',
    },
    {
      'date': '2025-03-15',
      'title': 'Prescription',
      'type': 'PDF',
      'description': 'Doctor prescription for medications.',
    },
    {
      'date': '2025-04-05',
      'title': 'MRI Scan',
      'type': 'Image',
      'description': 'MRI of the brain for checkup.',
    },
  ];

  Color _getTagColor(String type) {
    switch (type.toLowerCase()) {
      case 'pdf':
        return Colors.red.shade300;
      case 'image':
        return Colors.blue.shade300;
      case 'report':
        return Colors.green.shade300;
      default:
        return Colors.grey.shade300;
    }
  }

  IconData _getIcon(String type) {
    switch (type.toLowerCase()) {
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'image':
        return Icons.image;
      case 'report':
        return Icons.description;
      default:
        return Icons.insert_drive_file;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Medical Records'),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView.builder(
          itemCount: records.length,
          itemBuilder: (context, index) {
            final record = records[index];
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: _getTagColor(record['type']!),
                  child: Icon(_getIcon(record['type']!), color: Colors.white),
                ),
                title: Text(
                  record['title']!,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(record['description'] ?? ''),
                    const SizedBox(height: 4),
                    Text(
                      record['date']!,
                      style: const TextStyle(fontSize: 12, color: Colors.grey),
                    ),
                  ],
                ),
                trailing: IconButton(
                  icon: const Icon(Icons.download),
                  onPressed: () {
                    // handle download/view
                  },
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
