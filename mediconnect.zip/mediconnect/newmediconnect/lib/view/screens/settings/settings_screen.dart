import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../view_model/theme_view_model.dart';
import '../../widgets/custom_app_bar.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final themeViewModel = Provider.of<ThemeViewModel>(context);

    return Scaffold(
      appBar: CustomAppBar(title: 'Settings'),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text("Dark Mode"),
              value: themeViewModel.isDarkMode,
              onChanged: (value) {
                themeViewModel.toggleTheme(value);
              },
            ),
            const SizedBox(height: 20),
            const Text(
              'Change app appearance manually. Your choice will be saved.',
              style: TextStyle(fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }
}
