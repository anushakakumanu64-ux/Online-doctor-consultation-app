import 'package:flutter/material.dart';
import '../../widgets/custom_app_bar.dart';

class VideoCallScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(title: 'Video Call'),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.videocam, size: 64),
            SizedBox(height: 12),
            Text('Video Call Placeholder - integrate flutter_webrtc'),
          ],
        ),
      ),
    );
  }
}
