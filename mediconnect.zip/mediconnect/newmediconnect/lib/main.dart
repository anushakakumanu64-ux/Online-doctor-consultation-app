import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:device_preview/device_preview.dart';

import 'package:newmediconnect/view_model/theme_view_model.dart';

// 🌗 Theme
import 'core/theme/styles.dart';

// 🧭 Navigation & Constants
import 'core/utils/constants.dart';
import 'core/utils/navigation_service.dart';

// 🖥️ View Screens
import 'view/screens/splash/splash_screen.dart';
import 'view/screens/auth/login_screen.dart';
import 'view/screens/home/home_screen.dart';
import 'view/screens/doctor_list/doctor_list_screen.dart';
import 'view/screens/appointment/appointment_screen.dart';
import 'view/screens/video_call/video_call_screen.dart';
import 'view/screens/records/records_screen.dart';
import 'view/screens/prescription/prescription_screen.dart';
import 'view/screens/profile/profile_screen.dart';
import 'view/screens/settings/settings_screen.dart';

// 🧠 ViewModels
import 'view_model/auth_view_model.dart';
import 'view_model/home_view_model.dart';
import 'view_model/appointment_view_model.dart';
import 'view_model/profile_view_model.dart';
import 'view_model/settings_view_model.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize ThemeViewModel before running app
  final themeViewModel = ThemeViewModel();
  await themeViewModel.loadThemePreference();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
        ChangeNotifierProvider(create: (_) => HomeViewModel()),
        ChangeNotifierProvider(create: (_) => AppointmentViewModel()),
        ChangeNotifierProvider(create: (_) => ProfileViewModel()),
        ChangeNotifierProvider(create: (_) => SettingsViewModel()),
        ChangeNotifierProvider(create: (_) => ThemeViewModel()), // ✅ Theme Provider
      ],
      child: DevicePreview(
        enabled: true, // ✅ Enable preview mode
        builder: (context) => const MediConnectApp(),
      ),
    ),
  );
}

class MediConnectApp extends StatelessWidget {
  const MediConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeViewModel = Provider.of<ThemeViewModel>(context);

    return Consumer<ThemeViewModel>(
      builder: (context, themeVM, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'MediConnect',
          navigatorKey: NavigationService.navigatorKey,

          // ✅ Add DevicePreview support
          builder: DevicePreview.appBuilder,
          useInheritedMediaQuery: true,
          locale: DevicePreview.locale(context),

          theme: lightTheme,
          darkTheme: darkTheme,
          themeMode: themeViewModel.isDarkMode ? ThemeMode.dark : ThemeMode.light,

          // ✅ Localization (optional)
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          supportedLocales: const [
            Locale('en', 'US'),
          ],

          // ✅ Define all routes
          initialRoute: Routes.splash,
          routes: {
            Routes.splash: (_) => SplashScreen(),
            Routes.login: (_) => const AuthScreen(),
            Routes.home: (_) => const HomeScreen(),
            Routes.doctorList: (_) => DoctorListScreen(),
            Routes.appointment: (_) => AppointmentScreen(),
            Routes.videoCall: (_) => VideoCallScreen(),
            Routes.records: (_) => RecordsScreen(),
            Routes.prescription: (_) => PrescriptionScreen(),
            Routes.profile: (_) => const ProfileScreen(),
            Routes.settings: (_) => SettingsScreen(),
          },
        );
      },
    );
  }
}
