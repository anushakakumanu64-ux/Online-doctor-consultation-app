import 'package:flutter/material.dart';

class AppColors {
  static const Color tealLight = Color(0xFF00BFA6);
  static const primaryColor = Color(0xFF2196F3);
  static const primaryDark = Color(0xFF1565C0);
  static const backgroundDark = Color(0xFF121212);
  static const Color card = Colors.white;
  static const Color accent = tealLight;
  static const Color teal = Color(0xFF00A8A8);
  static const Color bg = Color(0xFFF5F5F5);
}
