class Routes {
  static const String splash = '/';
  static const String login = '/login';
  static const String home = '/home';
  static const String doctorList = '/doctors';
  static const String appointment = '/appointment';
  static const String videoCall = '/video_call';
  static const String records = '/records';
  static const String prescription = '/prescription';
  static const String profile = '/profile';
  static const String settings = '/settings';
}
