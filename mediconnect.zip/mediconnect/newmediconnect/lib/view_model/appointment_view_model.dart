import 'package:flutter/material.dart';

class AppointmentViewModel extends ChangeNotifier {
  // Store appointments in memory
  List<Map<String, dynamic>> _appointments = [];

  List<Map<String, dynamic>> get appointments => _appointments;

  void addAppointment(Map<String, dynamic> appointment) {
    _appointments.add(appointment);
    notifyListeners();
  }

  void removeAppointment(int index) {
    _appointments.removeAt(index);
    notifyListeners();
  }
}
