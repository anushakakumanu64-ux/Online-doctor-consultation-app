import 'package:flutter/material.dart';

class ProfileViewModel extends ChangeNotifier {
  String name = 'Ashoka M';
  String email = 'ashoka@example.com';

  void updateProfile(String n, String e) {
    name = n;
    email = e;
    notifyListeners();
  }
}
