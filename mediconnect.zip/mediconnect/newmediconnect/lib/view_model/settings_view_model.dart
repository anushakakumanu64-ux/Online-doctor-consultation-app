import 'package:flutter/material.dart';

class SettingsViewModel extends ChangeNotifier {
  bool notifications = true;
  void toggleNotifications() {
    notifications = !notifications;
    notifyListeners();
  }
}
