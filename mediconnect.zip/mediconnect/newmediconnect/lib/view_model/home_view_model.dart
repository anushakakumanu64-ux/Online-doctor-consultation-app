import 'package:flutter/material.dart';
import '../data/models/doctor.dart';
import '../data/services/mock_api_service.dart';

class HomeViewModel extends ChangeNotifier {
  List<Doctor> doctors = [];
  bool loading = false;

  Future<void> loadDoctors() async {
    loading = true;
    notifyListeners();
    doctors = await MockApiService.fetchDoctors();
    loading = false;
    notifyListeners();
  }
}
